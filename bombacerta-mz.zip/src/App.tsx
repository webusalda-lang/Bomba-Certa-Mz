import React, { useState, useEffect } from 'react';
import FuelMap from './components/FuelMap';
import StationList from './components/StationList';
import ReportForm from './components/ReportForm';
import { Station } from './types';
import { fuelService } from './services/fuelService';
import { auth, signInWithGoogle } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { formatDistanceToNow } from 'date-fns';
import { pt } from 'date-fns/locale';
import { Map as MapIcon, List, Info, PlusCircle, LogOut, User as UserIcon, RefreshCw, Filter, Share2 } from 'lucide-react';
import { Button, Badge, cn } from './components/Common';
import { AnimatePresence, motion } from 'motion/react';
import iconUrl from './icon.png';
import logoUrl from './assets/logo.svg';

export default function App() {
  const [stations, setStations] = useState<Station[]>([]);
  const [discoveredStations, setDiscoveredStations] = useState<Station[]>([]);
  const [viewMode, setViewMode] = useState<'map' | 'list'>('list');
  const [selectedStation, setSelectedStation] = useState<Station | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [nextRefreshIn, setNextRefreshIn] = useState(120);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [todayReportsCount, setTodayReportsCount] = useState(0);

  const refreshData = () => {
    setIsLoading(true);
    
    // Simulate satellite analysis for all stations
    stations.forEach(station => {
      const randomCongestion = Math.floor(Math.random() * 11);
      fuelService.updateStationTraffic(station.id, randomCongestion);
    });

    // The real-time listener for 'stations' (Firestore) is already active.
    // This manual refresh helps with 'discoveredStations' (Google Maps API)
    // and forces a UI state reset for a fresh look.
    setTimeout(() => {
      setIsLoading(false);
      setNextRefreshIn(120);
    }, 1500);
  };

  const shareToWhatsApp = () => {
    const availableStations = [...stations, ...discoveredStations].filter(s => s.currentStatus === "available");
    
    // Using Unicode escape sequences for emojis to ensure complete encoding safety
    let message = "*\u26FD BOMBA CERTA MZ - RESUMO DE DISPONIBILIDADE*\n\n";
    
    if (availableStations.length === 0) {
      message += "Nenhum posto com combust\u00EDvel confirmado no momento. \uD83D\uDE14\n\n";
    } else {
      message += "\u2705 *Postos com Combust\u00EDvel Dispon\u00EDvel:*\n\n";
      availableStations.forEach(s => {
        const fuels = [];
        if (s.hasGasoline) fuels.push("Gasolina");
        if (s.hasDiesel) fuels.push("Diesel");
        if (s.hasGNV) fuels.push("GNV");
        
        const fuelStatus = fuels.join(", ") || "Dispon\u00EDvel";
        const lastUpdate = s.updatedAt 
          ? formatDistanceToNow((s.updatedAt as any).toDate ? (s.updatedAt as any).toDate() : s.updatedAt, { locale: pt, addSuffix: true })
          : "Recentemente";

        message += `\u2705 *Status:* ${fuelStatus}\n`;
        message += `\u26FD *Bomba:* ${s.name} (${s.brand})\n`;
        message += `\uD83D\uDCCD *Localiza\u00E7\u00E3o:* ${s.address || "Ver no mapa"}\n`;
        message += `\u23F0 *Actualizado:* ${lastUpdate}\n\n`;
      });
    }
    
    const appUrl = window.location.origin;
    message += `\uD83D\uDC49 Veja mais detalhes em tempo real aqui:\n${appUrl}`;
    
    // Using the official api.whatsapp.com endpoint with mandatory encodeURIComponent
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;
    
    // Creating a temporary anchor tag is more robust for triggering protocol handlers in some browsers
    const link = document.createElement("a");
    link.href = whatsappUrl;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      document.body.removeChild(link);
    }, 100);
  };

  // Get user location for proximity sorting
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => console.error("Error getting location:", error)
      );
    }
  }, []);

  // Refresh Timer logic
  useEffect(() => {
    const timer = setInterval(() => {
      setNextRefreshIn((prev) => {
        if (prev <= 1) {
          refreshData();
          return 120;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
    });

    const unsubscribeStations = fuelService.getStations((data) => {
      setStations(data);
      setIsLoading(false);
      
      // Auto-update traffic demo logic
      // In a real app, this would be a server-side job calling TomTom/Google Traffic
    });

    const unsubscribeReportsCount = fuelService.getTodayTotalReports((count) => {
      setTodayReportsCount(count);
    });

    return () => {
      unsubscribeAuth();
      unsubscribeStations();
      unsubscribeReportsCount();
    };
  }, []);

  const handleSignOut = () => auth.signOut();

  const handleSeedData = async () => {
    if (!auth.currentUser) {
      try {
        await signInWithGoogle();
      } catch (error) {
        console.error("Erro ao fazer login:", error);
        return;
      }
    }

    if (!auth.currentUser) return;

    setIsLoading(true);
    const demoStations: Omit<Station, 'id' | 'createdAt' | 'updatedAt'>[] = [
      {
        name: "Galp - Avenida da Namaacha",
        brand: "Galp",
        location: { lat: -25.952, lng: 32.530 },
        address: "Av. da Namaacha, Maputo",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "long",
        hasGasoline: true,
        hasDiesel: true,
        hasGNV: false,
        trafficCongestion: 8,
        lastSatelliteAt: new Date(),
        satelliteUpdateCount: 3,
        lastFrequencyResetAt: new Date(),
        aiConfidence: 85
      },
      {
        name: "TotalEnergies - Jardim",
        brand: "TotalEnergies",
        location: { lat: -25.935, lng: 32.555 },
        address: "Av. de Moçambique, Jardim",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "short",
        hasGasoline: true,
        hasDiesel: false,
        hasGNV: false,
        trafficCongestion: 2,
        lastSatelliteAt: new Date(),
        satelliteUpdateCount: 1,
        lastFrequencyResetAt: new Date(),
        aiConfidence: 45
      },
      {
        name: "Petromoc - Baixa",
        brand: "Petromoc",
        location: { lat: -25.970, lng: 32.570 },
        address: "Av. 25 de Setembro, Baixa",
        createdBy: auth.currentUser.uid,
        currentStatus: "unavailable",
        queueStatus: "none",
        hasGasoline: false,
        hasDiesel: false,
        hasGNV: false,
        trafficCongestion: 1,
        lastSatelliteAt: new Date(),
        satelliteUpdateCount: 5,
        lastFrequencyResetAt: new Date(),
        aiConfidence: 92
      },
      {
        name: "Engen - Matola 700",
        brand: "Engen",
        location: { lat: -25.922, lng: 32.485 },
        address: "Av. Unidade Moçambicana, Matola",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "medium",
        hasGasoline: true,
        hasDiesel: true,
        hasGNV: true,
        trafficCongestion: 4,
        lastSatelliteAt: new Date()
      },
      {
        name: "Puma - Sommerschield",
        brand: "Puma",
        location: { lat: -25.958, lng: 32.595 },
        address: "Av. Mao Tsé Tung",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "extreme",
        hasGasoline: true,
        hasDiesel: true,
        hasGNV: false,
        trafficCongestion: 9,
        lastSatelliteAt: new Date()
      },
      {
        name: "Galp - Polana",
        brand: "Galp",
        location: { lat: -25.975, lng: 32.598 },
        address: "Av. Julius Nyerere",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "medium",
        hasGasoline: true,
        hasDiesel: true,
        hasGNV: false,
        trafficCongestion: 5,
        lastSatelliteAt: new Date()
      },
      {
        name: "Petromoc - Aeroporto",
        brand: "Petromoc",
        location: { lat: -25.925, lng: 32.578 },
        address: "Av. de Angola (Próximo ao Aeroporto)",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "long",
        hasGasoline: true,
        hasDiesel: true,
        hasGNV: false,
        trafficCongestion: 7,
        lastSatelliteAt: new Date()
      },
      {
        name: "TotalEnergies - Av. do Trabalho",
        brand: "TotalEnergies",
        location: { lat: -25.945, lng: 32.560 },
        address: "Av. do Trabalho",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "extreme",
        hasGasoline: true,
        hasDiesel: true,
        hasGNV: false,
        trafficCongestion: 10,
        lastSatelliteAt: new Date()
      },
      {
        name: "Cinergi - Matola",
        brand: "Cinergi",
        location: { lat: -25.905, lng: 32.465 },
        address: "Estrada Nacional EN4, Matola",
        createdBy: auth.currentUser.uid,
        currentStatus: "available",
        queueStatus: "short",
        hasGasoline: true,
        hasDiesel: true,
        hasGNV: false,
        trafficCongestion: 3,
        lastSatelliteAt: new Date()
      }
    ];

    try {
      for (const s of demoStations) {
        await fuelService.addStation(s);
      }
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDiscoveredTrafficUpdate = (stationId: string, congestion: number) => {
    setDiscoveredStations(prev => prev.map(s => {
      if (s.id === stationId) {
        let status = s.currentStatus;
        if (congestion >= 7) status = 'available';
        else if (congestion >= 3) status = 'unknown'; // Maybe
        else status = 'unavailable'; // Likely empty
        
        return { 
          ...s, 
          trafficCongestion: congestion,
          entryQueueLength: congestion * 5, // Estimate 5 cars per traffic level
          currentStatus: status,
          statusInferredBy: 'traffic',
          lastSatelliteAt: new Date(),
          updatedAt: new Date()
        };
      }
      return s;
    }));
  };

  return (
    <div className="h-screen w-full flex flex-col bg-slate-100 font-sans overflow-hidden">
      {/* Top Header - Bento Styled */}
      <header className="bg-white px-4 md:px-8 py-4 md:py-5 flex items-center justify-between border-b border-brand-green/10 z-50">
        <div className="flex items-center">
          <img 
            src={logoUrl} 
            alt="BombaCerta MZ" 
            className="h-12 md:h-20 lg:h-24 w-auto" 
          />
        </div>

        <div className="flex items-center gap-2 md:gap-4">
          <div className="flex items-center bg-brand-green/10 px-3 md:px-4 py-1.5 md:py-2 rounded-xl md:rounded-2xl border border-brand-green/20 shadow-sm">
            <div className="flex flex-col">
              <span className="text-[7px] md:text-[8px] font-black text-brand-green uppercase tracking-widest leading-none mb-0.5 md:mb-1">Reports Hoje</span>
              <div className="flex items-baseline gap-1">
                <span className="text-xs md:text-sm font-black text-brand-green italic leading-none">{todayReportsCount}</span>
                <span className="hidden xs:inline text-[6px] md:text-[7px] font-bold text-slate-400 uppercase italic leading-none">Confirmados</span>
              </div>
            </div>
          </div>

          <div className="hidden sm:flex items-center bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200">
            <RefreshCw size={12} className={cn("text-brand-green mr-2", nextRefreshIn < 10 && "animate-spin")} />
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
              Actualizar em: <span className="text-brand-green font-mono">
                {Math.floor(nextRefreshIn / 60)}:{String(nextRefreshIn % 60).padStart(2, '0')}
              </span>
            </span>
          </div>

          <div className="hidden md:flex items-center bg-brand-green/5 px-3 py-1.5 rounded-full border border-brand-green/10">
            <span className="flex h-2 w-2 rounded-full bg-brand-green mr-2 animate-pulse"></span>
            <span className="text-[10px] font-bold text-brand-green uppercase tracking-wider">Rede Activa</span>
          </div>
          
          {user ? (
            <div className="flex items-center gap-2">
              <button 
                onClick={handleSignOut}
                className="w-9 h-9 md:w-10 md:h-10 rounded-xl md:rounded-2xl border-2 border-slate-100 overflow-hidden flex items-center justify-center bg-slate-50 text-slate-400 hover:border-brand-green transition-all shadow-sm"
                title="Sair"
              >
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || ''} className="w-full h-full object-cover" />
                ) : (
                  <UserIcon size={18} />
                )}
              </button>
            </div>
          ) : (
            <button 
              onClick={signInWithGoogle}
              className="bg-brand-green text-white px-4 md:px-6 py-2 md:py-2.5 rounded-xl md:rounded-2xl font-black text-[10px] md:text-xs uppercase tracking-widest italic shadow-lg shadow-brand-green/20 hover:bg-brand-green/90 transition-all"
            >
              Entrar
            </button>
          )}
        </div>
      </header>

      {/* Main Content Area - Bento Grid on Desktop */}
      <main className="flex-1 p-2 md:p-6 grid grid-cols-12 gap-3 md:gap-6 overflow-hidden relative">
        
        {/* Left Column: Bento Stats (Visible on LG screens) */}
        <div className="hidden lg:flex col-span-3 flex-col gap-6 overflow-y-auto">
          {/* Featured Station Card */}
          <div className="bento-card p-6 flex flex-col min-h-[300px]">
            <div className="flex justify-between items-start mb-6">
              <Badge variant="info">Destaque</Badge>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Maputo City</span>
            </div>
            
            <div className="flex-1">
              <h2 className="text-2xl font-black text-brand-black leading-tight mb-1 uppercase italic">Estado do Trânsito</h2>
              <p className="text-sm text-slate-500 mb-6 font-medium">Monitorização de filas baseada em fluxo TomTom</p>
              
              <div className="space-y-4">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <div className="flex justify-between text-[10px] font-black mb-2 uppercase tracking-tighter text-slate-400">
                    <span>Média de Espera</span>
                    <span className="text-brand-green">32 min</span>
                  </div>
                  <div className="flex gap-1">
                    <div className="h-2 flex-1 rounded-full bg-brand-green"></div>
                    <div className="h-2 flex-1 rounded-full bg-brand-green/20"></div>
                    <div className="h-2 flex-1 rounded-full bg-brand-green/20"></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100 mt-6 grid grid-cols-2 gap-3">
              <div className="bg-brand-green/5 p-3 rounded-2xl border border-brand-green/10">
                <p className="text-[10px] uppercase font-black text-brand-green tracking-tighter">Reportes</p>
                <p className="text-xl font-black text-brand-green italic">+1.2k</p>
              </div>
              <div className="bg-brand-yellow/10 p-3 rounded-2xl border border-brand-yellow/20">
                <p className="text-[10px] uppercase font-black text-brand-yellow tracking-tighter">Ativos</p>
                <p className="text-xl font-black text-slate-900 italic">384</p>
              </div>
            </div>
          </div>

          {/* Stats Boxes */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-brand-green bento-card p-4 text-white border-none shadow-lg shadow-brand-green/20">
              <div className="text-2xl mb-2 italic">💎</div>
              <h3 className="text-[10px] font-black text-brand-yellow uppercase tracking-widest mb-1 italic">Expert</h3>
              <p className="text-2xl font-black italic">TOP 5%</p>
            </div>
            <div className="bento-card p-4">
              <div className="text-2xl mb-2">📊</div>
              <h3 className="text-[10px] font-black text-brand-green uppercase tracking-widest mb-1">Total</h3>
              <p className="text-2xl font-black italic text-brand-black">4,8k</p>
            </div>
          </div>
        </div>

        {/* Center/Right Column: Main View (Map or List) */}
        <div className="col-span-12 lg:col-span-9 relative flex flex-col overflow-hidden min-h-0">
          {/* Navigation Controls */}
          <div className="flex justify-center bg-white rounded-[20px] md:rounded-[24px] shadow-sm border border-brand-green/10 p-1.5 md:p-2 gap-1.5 md:gap-2 shrink-0 mb-3 md:mb-4">
            <button
              onClick={() => setViewMode('map')}
              className={cn(
                "flex items-center gap-1.5 md:gap-2 px-4 md:px-6 py-2 md:py-3 rounded-[14px] md:rounded-2xl transition-all font-black text-[10px] md:text-xs uppercase tracking-widest italic",
                viewMode === 'map' ? "bg-brand-green text-white shadow-xl shadow-brand-green/20" : "text-slate-400 hover:text-brand-green"
              )}
            >
              <MapIcon size={14} className="md:w-[18px] md:h-[18px]" /> Mapa
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={cn(
                "flex items-center gap-1.5 md:gap-2 px-4 md:px-6 py-2 md:py-3 rounded-[14px] md:rounded-2xl transition-all font-black text-[10px] md:text-xs uppercase tracking-widest italic",
                viewMode === 'list' ? "bg-brand-green text-white shadow-xl shadow-brand-green/20" : "text-slate-400 hover:text-brand-green"
              )}
            >
              <List size={14} className="md:w-[18px] md:h-[18px]" /> Lista
            </button>
            <div className="w-px bg-slate-100 my-2 mx-1 opacity-50" />
            <button
              onClick={shareToWhatsApp}
              className="flex items-center gap-1.5 md:gap-2 px-4 md:px-6 py-2 md:py-3 rounded-[14px] md:rounded-2xl transition-all font-black text-[10px] md:text-xs uppercase tracking-widest italic text-brand-green hover:bg-brand-green/5"
            >
              <Share2 size={14} className="md:w-[18px] md:h-[18px]" /> Partilhar
            </button>
          </div>

          {isLoading ? (
            <div className="flex-1 flex items-center justify-center">
              <div className="flex flex-col items-center gap-3">
                <div className="w-12 h-12 border-4 border-brand-green border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs font-black uppercase tracking-widest text-slate-400 italic">Calculando Redes...</p>
              </div>
            </div>
          ) : (
            <>
              <div className="flex-1 relative rounded-[24px] md:rounded-[32px] overflow-hidden border-2 md:border-4 border-white shadow-2xl flex flex-col min-h-0">
                {viewMode === 'map' ? (
                  <FuelMap 
                    stations={stations} 
                    discoveredStations={discoveredStations}
                    onSelectStation={setSelectedStation} 
                    onDiscoverStations={setDiscoveredStations}
                    onDiscoveredTrafficUpdate={handleDiscoveredTrafficUpdate}
                  />
                ) : (
                  <StationList 
                    stations={[...stations, ...discoveredStations]} 
                    onSelectStation={setSelectedStation} 
                    userLocation={userLocation}
                  />
                )}

                {/* Refresh Timer Bar */}
                {viewMode === 'list' && (
                  <div className="absolute top-4 left-4 right-4 z-20 flex items-center justify-center">
                    <div className="bg-white/95 backdrop-blur-md px-6 py-3 rounded-[24px] border border-brand-green/20 shadow-xl flex items-center gap-3">
                      <div className="relative">
                        <RefreshCw size={14} className={cn("text-brand-green", nextRefreshIn < 10 && "animate-spin")} />
                        {nextRefreshIn < 10 && (
                          <span className="absolute -top-1 -right-1 flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-green opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-green"></span>
                          </span>
                        )}
                      </div>
                      <div className="flex flex-col text-left">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] leading-none mb-1">Próxima Actualização</span>
                        <div className="flex items-end gap-1">
                          <span className="text-sm font-black text-brand-black leading-none font-mono tracking-tighter">
                            {Math.floor(nextRefreshIn / 60)}:{String(nextRefreshIn % 60).padStart(2, '0')}
                          </span>
                          <span className="text-[8px] font-black text-brand-green uppercase italic leading-none mb-0.5 animate-pulse">Tempo</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {stations.length < 5 && !isLoading && (
                  <div className="absolute inset-0 z-[2000] flex items-center justify-center bg-white/60 backdrop-blur-sm pointer-events-none p-4">
                    <div className="text-center p-6 md:p-10 max-w-sm bento-card bg-white shadow-2xl pointer-events-auto border-2 border-brand-green/10">
                      <div className="w-16 h-16 md:w-20 md:h-20 bg-brand-green text-white rounded-[20px] md:rounded-[24px] flex items-center justify-center mx-auto mb-4 md:mb-6 shadow-xl shadow-brand-green/20">
                        <MapIcon size={32} className="italic" />
                      </div>
                      <h3 className="text-xl md:text-2xl font-black text-slate-900 mb-2 md:mb-3 italic uppercase tracking-tighter">Expandir Rede</h3>
                      <p className="text-xs md:text-sm text-slate-500 mb-6 md:mb-8 font-medium leading-relaxed">
                        Detectamos poucos postos na sua área. Deseja carregar a base de dados completa de <strong>Maputo e Matola</strong>?
                      </p>
                      <button 
                        onClick={handleSeedData}
                        className="w-full py-3 md:py-4 text-brand-green font-black uppercase italic tracking-widest border-2 border-brand-green hover:bg-brand-green hover:text-white transition-all rounded-[12px] md:rounded-[16px] text-xs md:text-sm"
                      >
                        CARREGAR MAPUTO
                      </button>
                      <p className="mt-4 text-[8px] md:text-[10px] text-brand-green font-bold uppercase tracking-widest italic">Inclui detecção de filas em tempo real</p>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </main>

      {/* Side Notification Drawer (Optional info) */}
      <div className="hidden lg:block fixed right-6 top-24 w-64 space-y-4">
        <div className="bg-white p-5 rounded-3xl shadow-sm border border-brand-green/10">
          <div className="flex items-center gap-2 text-brand-green mb-3">
            <Info size={18} />
            <span className="font-bold text-sm leading-tight italic">O que são anéis coloridos?</span>
          </div>
          <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
            Os anéis mostram o estado da fila detetado por outros motoristas e análise de tráfego local. 
            <br/><br/>
            Círculos em <b className="text-brand-green">Verde</b> indicam fluxo livre. <b className="text-brand-yellow">Amarelo</b> para filas médias. <b className="text-red-500">Vermelho</b> para filas intensas.
          </p>
        </div>
      </div>

      {/* Reporting Modal */}
      <AnimatePresence>
        {selectedStation && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedStation(null)}
              className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[1500]"
            />
            <ReportForm 
              station={selectedStation} 
              onClose={() => setSelectedStation(null)} 
            />
          </>
        )}
      </AnimatePresence>

      {/* Mobile Footer Spacing */}
      <div className="h-safe-bottom bg-white shrink-0 sm:hidden"></div>
    </div>
  );
}
