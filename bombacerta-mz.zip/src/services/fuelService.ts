import { 
  collection, 
  addDoc, 
  updateDoc, 
  doc, 
  getDoc,
  getDocs, 
  query, 
  orderBy, 
  serverTimestamp, 
  where,
  onSnapshot,
  collectionGroup,
  Timestamp
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Station, Report, OperationType, FirestoreErrorInfo } from '../types';

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const STATIONS_COLLECTION = 'stations';

export const fuelService = {
  getStations: (callback: (stations: Station[]) => void) => {
    const q = query(collection(db, STATIONS_COLLECTION));
    return onSnapshot(q, (snapshot) => {
      const stations = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Station[];
      callback(stations);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, STATIONS_COLLECTION);
    });
  },

  getTodayTotalReports: (callback: (count: number) => void) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // We use collectionGroup to query all 'reports' subcollections
    const q = query(
      collectionGroup(db, 'reports'),
      where('createdAt', '>=', Timestamp.fromDate(today))
    );

    return onSnapshot(q, (snapshot) => {
      callback(snapshot.size);
    }, (error) => {
      console.error("Error fetching today's reports:", error);
    });
  },

  addStation: async (station: Omit<Station, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const docRef = await addDoc(collection(db, STATIONS_COLLECTION), {
        ...station,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, STATIONS_COLLECTION);
    }
  },

  addReport: async (stationId: string, report: Omit<Report, 'id' | 'createdAt'>) => {
    const reportsPath = `${STATIONS_COLLECTION}/${stationId}/reports`;
    try {
      // 1. Add the report
      await addDoc(collection(db, reportsPath), {
        ...report,
        createdAt: serverTimestamp(),
      });

      // 2. Update the station summary
      const stationRef = doc(db, STATIONS_COLLECTION, stationId);
      await updateDoc(stationRef, {
        hasGasoline: report.hasGasoline,
        hasDiesel: report.hasDiesel,
        hasGNV: report.hasGNV,
        queueStatus: report.queueLevel,
        entryQueueLength: report.entryQueueLength || 0,
        lastReportedAt: serverTimestamp(),
        lastComment: report.comment || null,
        lastCommenter: report.userName || 'Anónimo',
        lastHumanAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, reportsPath);
    }
  },

  updateStationTraffic: async (stationId: string, congestionValue: number) => {
    try {
      const stationRef = doc(db, STATIONS_COLLECTION, stationId);
      const stationSnap = await getDoc(stationRef);
      
      let count = 1;
      let resetAt = serverTimestamp();

      if (stationSnap.exists()) {
        const data = stationSnap.data() as Station;
        const lastReset = data.lastFrequencyResetAt?.toDate();
        const now = new Date();
        
        if (lastReset && (now.getTime() - lastReset.getTime() < 3600000)) {
          count = (data.satelliteUpdateCount || 0) + 1;
          resetAt = data.lastFrequencyResetAt;
        }
      }

      const updates: any = {
        trafficCongestion: congestionValue,
        updatedAt: serverTimestamp(),
        lastSatelliteAt: serverTimestamp(),
        satelliteUpdateCount: count,
        lastFrequencyResetAt: resetAt,
        aiConfidence: Math.min(100, 40 + (count * 15) + Math.floor(Math.random() * 20)),
        entryQueueLength: congestionValue * 5, 
        statusInferredBy: 'traffic'
      };

      // User's requested inference rules:
      if (congestionValue >= 7) {
        updates.currentStatus = 'available';
      } else if (congestionValue >= 3) {
        updates.currentStatus = 'unknown'; // Signals "Maybe/Uncertain"
      } else {
        updates.currentStatus = 'unavailable';
      }

      await updateDoc(stationRef, updates);
    } catch (error) {
      console.error("Traffic update error:", error);
    }
  },

  getReports: (stationId: string, callback: (reports: Report[]) => void) => {
    const reportsPath = `${STATIONS_COLLECTION}/${stationId}/reports`;
    const q = query(collection(db, reportsPath), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const reports = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Report[];
      callback(reports);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, reportsPath);
    });
  }
};
