export type Brand = "Galp" | "TotalEnergies" | "Petromoc" | "Engen" | "Puma" | "Cinergi" | "Other";
export type QueueLevel = "none" | "short" | "medium" | "long" | "extreme";
export type StationStatus = "available" | "limited" | "unavailable" | "unknown";

export interface GeoLocation {
  lat: number;
  lng: number;
}

export interface Station {
  id: string;
  name: string;
  brand: Brand;
  location: GeoLocation;
  placeId?: string;
  address?: string;
  createdBy: string;
  createdAt: any;
  updatedAt: any;
  currentStatus: StationStatus;
  queueStatus: QueueLevel;
  trafficCongestion?: number; // 0-10 jam factor
  entryQueueLength?: number; // Estimated number of cars waiting
  hasGasoline: boolean;
  hasDiesel: boolean;
  hasGNV: boolean;
  lastReportedAt?: any;
  lastComment?: string;
  lastCommenter?: string;
  statusInferredBy?: 'user' | 'traffic';
  lastSatelliteAt?: any;
  lastHumanAt?: any;
  satelliteUpdateCount?: number;
  lastFrequencyResetAt?: any;
  aiConfidence?: number; // 0-100 confidence score
}

export interface Report {
  id?: string;
  stationId: string;
  userId: string;
  userName: string;
  hasGasoline: boolean;
  hasDiesel: boolean;
  hasGNV: boolean;
  queueLevel: QueueLevel;
  entryQueueLength?: number;
  comment?: string;
  createdAt: any;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}
