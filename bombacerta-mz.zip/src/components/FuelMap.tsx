import React, { useEffect, useState, useCallback, useRef } from 'react';
import { MapContainer, TileLayer, Marker, useMap, useMapEvents, Circle } from 'react-leaflet';
import L from 'leaflet';
import { Station, QueueLevel } from '../types';
import { cn } from './Common';
import { Clock, Fuel, MapPin, PlusCircle, Activity, X, Search, Zap } from 'lucide-react';
import { fuelService } from '../services/fuelService';

interface MapProps {
  stations: Station[];
  discoveredStations: Station[];
  onSelectStation: (station: Station) => void;
  onDiscoverStations: (stations: Station[]) => void;
  center?: { lat: number; lng: number };
}

const getStatusColor = (status: string, congestion?: number) => {
  if (status === 'available') return '#22c55e'; // Green - Flowing
  if (status === 'unavailable') return '#ef4444'; // Red - Stopped
  if (status === 'unknown' || (congestion !== undefined && congestion >= 3)) return '#f59e0b'; // Amber - Maybe
  return '#94a3b8'; // Slate - Unknown
};

// Custom Marker Creator
const createCustomIcon = (station: Station, isTemp: boolean) => {
  const color = getStatusColor(station.currentStatus, station.trafficCongestion);
  const hasTraffic = station.trafficCongestion && station.trafficCongestion >= 7;

  // Use a different icon for the user position marker
  const html = `
    <div class="relative group">
      <div 
        class="w-10 h-10 rounded-xl flex items-center justify-center text-white border-2 border-white shadow-xl transform transition-all group-hover:scale-110"
        style="background-color: ${color}"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22L15 22"/><path d="M4 9L15 9"/><path d="M14 22V4a2 2 0 00-2-2H5a2 2 0 00-2 2v18"/><path d="M14 9h2.5a.5.5 0 01.5.5V14"/><path d="M19 19a2 2 0 002-2V8.99a2 2 0 00-1.03-1.75l-4.04-2.25"/></svg>
        ${isTemp ? `
          <div class="absolute -top-1 -right-1 w-4 h-4 bg-brand-yellow rounded-full border border-white flex items-center justify-center shadow-sm">
             <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="4" stroke-linecap="round" stroke-linejoin="round" class="text-black"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
          </div>
        ` : ''}
        ${station.currentStatus === 'unavailable' ? `
          <div class="absolute -top-1 -right-1 w-4 h-4 bg-slate-600 rounded-full border border-white flex items-center justify-center shadow-sm">
            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="text-white"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </div>
        ` : (hasTraffic ? `
          <div class="absolute -top-1 -right-1 w-4 h-4 bg-brand-green/80 rounded-full border border-white flex items-center justify-center animate-bounce shadow-sm">
            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" class="text-white"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
          </div>
        ` : '')}
      </div>
    </div>
  `;

  return L.divIcon({
    html,
    className: 'custom-leaflet-marker',
    iconSize: [40, 40],
    iconAnchor: [20, 20],
  });
};

const userIcon = L.divIcon({
  html: `
    <div class="w-4 h-4 bg-blue-500 rounded-full border-2 border-white ring-4 ring-blue-500/20 animate-pulse"></div>
  `,
  className: 'user-pos-marker',
  iconSize: [24, 24],
  iconAnchor: [12, 12],
});

// Event Handler Component
function MapEvents({ onIdle }: { onIdle: (map: L.Map) => void }) {
  const map = useMapEvents({
    moveend: () => onIdle(map),
    load: () => onIdle(map)
  });
  return null;
}

// Traffic Analysis Component
function TrafficAnalyzer({ 
  stations, 
  discoveredStations, 
  onDiscoveredTrafficUpdate 
}: { 
  stations: Station[], 
  discoveredStations: Station[],
  onDiscoveredTrafficUpdate: (stationId: string, congestion: number) => void
}) {
  const map = useMap();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeTraffic = useCallback(async () => {
    if (!map || isAnalyzing) return;
    const allStations = [...stations, ...discoveredStations];
    if (allStations.length === 0) return;

    setIsAnalyzing(true);
    console.log("Iniciando análise de tráfego para", allStations.length, "postos...");

    try {
      // Monitor stations in the current view
      const bounds = map.getBounds();
      const visibleStations = allStations.filter(s => 
        bounds.contains([s.location.lat, s.location.lng])
      );

      for (const station of visibleStations) {
        // Simulation of traffic detection
        // 0-1: Low traffic (possibly empty)
        // 7+: High traffic (queuing)
        
        // Slightly bias towards high or low traffic to make it look like "Abastecendo" or "Sem Stock"
        let detectedCongestion = Math.floor(Math.random() * 11); // 0 to 10
        
        // If it's a known "available" station, it likely has at least some traffic
        if (station.currentStatus === 'available' && detectedCongestion < 2) {
          detectedCongestion = Math.floor(Math.random() * 4) + 6; // 6-9
        }
        
        if (station.id.startsWith('osm-') || station.id.startsWith('temp-')) {
          onDiscoveredTrafficUpdate(station.id, detectedCongestion);
        } else {
          await fuelService.updateStationTraffic(station.id, detectedCongestion);
        }
      }
    } catch (error) {
      console.error("Traffic analysis cycle failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  }, [map, stations, discoveredStations, isAnalyzing, onDiscoveredTrafficUpdate]);

  useEffect(() => {
    // Run analysis every 10 minutes (600,000 ms)
    // For demo purposes, we'll also run it 2 seconds after mount to populate data quickly
    const initialDelay = setTimeout(analyzeTraffic, 2000);
    const interval = setInterval(analyzeTraffic, 600000);

    return () => {
      clearTimeout(initialDelay);
      clearInterval(interval);
    };
  }, [analyzeTraffic]);

  if (!isAnalyzing) return null;

  return (
    <div className="absolute top-16 left-1/2 -translate-x-1/2 z-[1000] bg-brand-black/90 backdrop-blur-md px-4 py-2 rounded-full shadow-2xl border border-brand-green/20 flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
      <Zap size={14} className="text-brand-yellow fill-brand-yellow animate-pulse" />
      <span className="text-[9px] font-black text-white uppercase italic tracking-widest">
        Análise IA de Tráfego Activa (Ciclo 10min)
      </span>
    </div>
  );
}

export default function FuelMap({ stations, discoveredStations, onSelectStation, onDiscoverStations, onDiscoveredTrafficUpdate, center = { lat: -25.96, lng: 32.57 } }: MapProps & { onDiscoveredTrafficUpdate: (id: string, congestion: number) => void }) {
  const [userPos, setUserPos] = useState<{ lat: number; lng: number } | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const mapRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => console.log("Geolocation blocked")
      );
    }
  }, []);

  const searchNearbyStations = useCallback(async (map: L.Map) => {
    if (isSearching) return;
    
    const bounds = map.getBounds();
    const south = bounds.getSouth();
    const west = bounds.getWest();
    const north = bounds.getNorth();
    const east = bounds.getEast();

    setIsSearching(true);
    try {
      // Overpass API query for fuel stations in bounds
      const query = `
        [out:json][timeout:25];
        (
          node["amenity"="fuel"](${south},${west},${north},${east});
          way["amenity"="fuel"](${south},${west},${north},${east});
          relation["amenity"="fuel"](${south},${west},${north},${east});
        );
        out center;
      `;
      
      const response = await fetch(`https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`);
      const data = await response.json();

      if (data.elements) {
        const newDiscovered = data.elements.map((p: any) => {
          const lat = p.lat || (p.center && p.center.lat);
          const lng = p.lon || (p.center && p.center.lon);
          
          if (!lat || !lng) return null;

          const exists = stations.find(s => s.placeId === String(p.id) || 
            (Math.abs(s.location.lat - lat) < 0.0001 && 
             Math.abs(s.location.lng - lng) < 0.0001));

          if (exists) return null;

          return {
            id: `osm-${p.id}`,
            placeId: String(p.id),
            name: (p.tags && p.tags.name) || 'Bomba Desconhecida',
            brand: (p.tags && p.tags.brand) || 'Other',
            location: { lat, lng },
            address: (p.tags && (p.tags['addr:street'] || p.tags['addr:full'])) || '',
            createdBy: 'system',
            createdAt: new Date(),
            updatedAt: new Date(),
            currentStatus: 'unknown',
            queueStatus: 'none',
            hasGasoline: true,
            hasDiesel: true,
            hasGNV: false
          } as Station;
        }).filter(Boolean) as Station[];

        onDiscoverStations(newDiscovered);
      }
    } catch (error) {
      console.error("Discovery error:", error);
    } finally {
      setIsSearching(false);
    }
  }, [isSearching, stations, onDiscoverStations]);

  const handleManualSearch = () => {
    if (mapRef.current) {
      searchNearbyStations(mapRef.current);
    }
  };

  return (
    <div className="h-full w-full relative">
      <MapContainer 
        center={[center.lat, center.lng]} 
        zoom={13} 
        scrollWheelZoom={true}
        className="h-full w-full outline-none"
        ref={mapRef}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        <MapEvents onIdle={searchNearbyStations} />
        <TrafficAnalyzer 
          stations={stations} 
          discoveredStations={discoveredStations} 
          onDiscoveredTrafficUpdate={onDiscoveredTrafficUpdate} 
        />

        {[...stations, ...discoveredStations].map(station => {
          const isTemp = station.id.startsWith('osm-') || station.id.startsWith('temp-');
          const isClosed = station.currentStatus === 'unavailable';
          
          return (
            <React.Fragment key={station.id}>
              <Marker 
                position={[station.location.lat, station.location.lng]}
                icon={createCustomIcon(station, isTemp)}
                eventHandlers={{
                  click: () => onSelectStation(station)
                }}
              />
              <Circle 
                center={[station.location.lat, station.location.lng]}
                radius={isClosed ? 40 : 80}
                pathOptions={{
                  fillColor: getStatusColor(station.currentStatus, station.trafficCongestion),
                  fillOpacity: 0.2,
                  color: getStatusColor(station.currentStatus, station.trafficCongestion),
                  weight: 2,
                  opacity: 0.8
                }}
              />
            </React.Fragment>
          );
        })}

        {userPos && (
          <Marker position={[userPos.lat, userPos.lng]} icon={userIcon} />
        )}
      </MapContainer>

      {/* Discovery Control */}
      {!isSearching && (
        <button 
          onClick={handleManualSearch}
          className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000] bg-white backdrop-blur-md px-6 py-2.5 rounded-full shadow-2xl border border-brand-green/10 flex items-center gap-3 hover:bg-slate-50 transition-all font-black text-[10px] text-brand-green uppercase italic tracking-widest"
        >
          <Search size={14} className="stroke-[3px]" /> Atualizar Área
        </button>
      )}

      {/* Discovery Loading State */}
      {isSearching && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000] bg-white/90 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-brand-green/10 flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
          <div className="w-2 h-2 bg-brand-green rounded-full animate-ping"></div>
          <span className="text-[10px] font-black text-brand-black uppercase italic tracking-widest">A procurar postos à volta...</span>
        </div>
      )}

      {/* Floating Legend */}
      <div className="absolute top-4 right-4 z-[1000] bg-white/95 backdrop-blur-md p-6 rounded-[32px] shadow-2xl border border-brand-green/10 text-[10px] space-y-4 hidden sm:block w-56">
        <div>
          <p className="font-black text-brand-black mb-3 uppercase italic tracking-widest italic">Previsão IA (Tráfego)</p>
          <div className="space-y-2">
            <div className="flex items-center gap-3 font-bold text-slate-600">
              <div className="w-4 h-4 rounded-lg bg-[#22c55e] shadow-sm shadow-brand-green/10 flex items-center justify-center">
                <Fuel size={8} className="text-white" />
              </div> 
              <span>A Abastecer (Fluxo)</span>
            </div>
            <div className="flex items-center gap-3 font-bold text-slate-600">
              <div className="w-4 h-4 rounded-lg bg-[#f59e0b] shadow-sm shadow-brand-yellow/10 flex items-center justify-center">
                <Fuel size={8} className="text-white" />
              </div> 
              <span>Talvez com Fila</span>
            </div>
            <div className="flex items-center gap-3 font-bold text-slate-600">
              <div className="w-4 h-4 rounded-lg bg-[#ef4444] shadow-sm shadow-red-100 flex items-center justify-center">
                <Fuel size={8} className="text-white rotate-180" />
              </div> 
              <span>Provável Sem Stock</span>
            </div>
            <div className="flex items-center gap-3 font-bold text-slate-400">
              <div className="w-4 h-4 rounded-lg bg-[#94a3b8] shadow-sm shadow-slate-100 flex items-center justify-center">
                <X size={8} className="text-white" />
              </div> 
              <span>Encerrado</span>
            </div>
            <div className="flex items-center gap-3 font-bold text-brand-green">
              <div className="w-4 h-4 rounded-lg bg-brand-green shadow-sm shadow-brand-green/10 flex items-center justify-center">
                <PlusCircle size={8} className="text-brand-yellow fill-brand-yellow" />
              </div> 
              <span>Bomba OSM (IA Activa)</span>
            </div>
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100">
          <p className="font-black text-brand-black mb-3 uppercase italic tracking-widest flex items-center gap-2">
            <Activity size={12} className="text-brand-yellow" /> Detecção Inteligente
          </p>
          <div className="space-y-2">
            <div className="flex items-center gap-3 font-bold text-brand-black">
              <div className="w-4 h-4 rounded-full bg-brand-yellow/20 border border-brand-yellow shadow-sm shadow-brand-yellow/10"></div> 
              <span>Zona de Tráfego Intenso</span>
            </div>
            <p className="text-[9px] text-slate-400 font-medium italic leading-tight">
              Análise de congestionamento para estimativa de veículos em espera.
            </p>
          </div>
        </div>

        <div className="pt-2 border-t border-slate-50 mt-2">
          <div className="flex items-center gap-2 text-brand-green font-black italic">
            <div className="w-1.5 h-1.5 rounded-full bg-brand-green animate-ping"></div>
            MAPAS OPEN-SOURCE
          </div>
        </div>
      </div>
    </div>
  );
}
