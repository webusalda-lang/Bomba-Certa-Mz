import React, { useState, useEffect } from 'react';
import { Station, QueueLevel, Report } from '../types';
import { Button, Badge, cn } from './Common';
import { Fuel, Clock, MessageSquare, X, Send, LogIn, History, Info, MapPin, PlusCircle, Activity, Zap, Check, Edit3 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { auth, signInWithGoogle } from '../lib/firebase';
import { fuelService } from '../services/fuelService';
import { formatDistanceToNow } from 'date-fns';
import { pt } from 'date-fns/locale';

interface ReportFormProps {
  station: Station;
  onClose: () => void;
}

export default function ReportForm({ station, onClose }: ReportFormProps) {
  const [hasGasoline, setHasGasoline] = useState(station.hasGasoline);
  const [hasDiesel, setHasDiesel] = useState(station.hasDiesel);
  const [hasGNV, setHasGNV] = useState(station.hasGNV);
  const [queueLevel, setQueueLevel] = useState<QueueLevel>(station.queueStatus);
  const [entryQueueValue, setEntryQueueValue] = useState(station.entryQueueLength || 0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'report'>('info');
  const [reports, setReports] = useState<Report[]>([]);
  const [isVerifying, setIsVerifying] = useState(true);

  useEffect(() => {
    // Reset verification state when switching back to info or starting fresh
    if (activeTab === 'info') {
      setIsVerifying(true);
    }
  }, [activeTab]);

  useEffect(() => {
    const unsubscribe = fuelService.getReports(station.id, (data) => {
      setReports(data);
    });
    return () => unsubscribe();
  }, [station.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Anonymous reporting is allowed as per user request
    const currentUserId = auth.currentUser?.uid || 'guest';
    const currentUserName = auth.currentUser?.displayName || 'Convidado';

    setIsSubmitting(true);
    try {
      let stationId = station.id;

      // If this is a discovered station from Google, we need to create it in our DB first
      if (stationId.startsWith('temp-')) {
        const newStationId = await fuelService.addStation({
          name: station.name,
          brand: station.brand,
          location: station.location,
          placeId: station.placeId || '',
          address: station.address || '',
          createdBy: currentUserId,
          currentStatus: 'available',
          queueStatus: queueLevel,
          entryQueueLength: entryQueueValue,
          hasGasoline,
          hasDiesel,
          hasGNV,
          trafficCongestion: 0
        });
        if (newStationId) stationId = newStationId;
      }

      await fuelService.addReport(stationId, {
        stationId,
        userId: currentUserId,
        userName: currentUserName,
        hasGasoline,
        hasDiesel,
        hasGNV,
        queueLevel,
        entryQueueLength: entryQueueValue,
        comment
      });
      onClose();
    } catch (error) {
      console.error(error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const queueOptions: { value: QueueLevel; label: string; color: string }[] = [
    { value: 'none', label: 'Livre', color: 'bg-emerald-500' },
    { value: 'short', label: 'Curta', color: 'bg-lime-500' },
    { value: 'medium', label: 'Média', color: 'bg-amber-500' },
    { value: 'long', label: 'Longa', color: 'bg-orange-500' },
    { value: 'extreme', label: 'Extrema', color: 'bg-rose-500' },
  ];

  return (
    <motion.div 
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed bottom-0 lg:bottom-6 left-0 right-0 z-[2000] bg-white rounded-t-[32px] lg:rounded-[32px] shadow-2xl overflow-hidden pb-safe max-w-xl mx-auto border-t lg:border border-slate-200 flex flex-col max-h-[90vh]"
    >
      <div className="p-8 pb-4 shrink-0">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-2xl bg-brand-green flex items-center justify-center text-white font-black italic shadow-lg shadow-brand-green/20 uppercase">
              {station.brand[0]}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-xl font-black text-brand-black uppercase italic leading-tight">{station.name}</h2>
                {station.currentStatus === 'available' ? (
                  <Badge variant="success" className="font-black italic uppercase text-[9px] flex items-center gap-1">
                    <Fuel size={10} /> A Abastecer
                  </Badge>
                ) : station.currentStatus === 'unavailable' ? (
                  <Badge variant="danger" className="font-black italic uppercase text-[9px] flex items-center gap-1">
                    <Fuel size={10} className="rotate-180" /> Sem Stock
                  </Badge>
                ) : (
                  <Badge variant="warning" className="font-black italic uppercase text-[9px] flex items-center gap-1">
                    <Fuel size={10} /> Stock Incerto
                  </Badge>
                )}
              </div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{station.brand}</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-3 rounded-2xl bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors shadow-sm"
          >
            <X size={20} />
          </button>
        </div>

        {/* Bento Tabs */}
        <div className="flex gap-2 bg-slate-50 p-1.5 rounded-2xl border border-slate-100">
          <button
            onClick={() => setActiveTab('info')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest italic transition-all",
              activeTab === 'info' ? "bg-white text-brand-green shadow-sm" : "text-slate-400 hover:text-slate-500"
            )}
          >
            <Info size={14} /> Informação
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest italic transition-all",
              activeTab === 'report' ? "bg-white text-brand-green shadow-sm" : "text-slate-400 hover:text-slate-500"
            )}
          >
            <PlusCircle size={14} className="stroke-[3px]" /> Reportar
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-8 pb-8">
        <AnimatePresence mode="wait">
          {activeTab === 'info' ? (
            <motion.div
              key="info"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="space-y-6"
            >
              {/* Current Status Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bento-card p-5 bg-slate-50/50 border-slate-100">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 italic">Disponibilidade</p>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-600">Gasolina</span>
                      {station.hasGasoline ? <Badge variant="success">Tem</Badge> : <Badge variant="outline">Sem</Badge>}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-600">Diesel</span>
                      {station.hasDiesel ? <Badge variant="success">Tem</Badge> : <Badge variant="outline">Sem</Badge>}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-600">GNV</span>
                      {station.hasGNV ? <Badge variant="success">Tem</Badge> : <Badge variant="outline">Sem</Badge>}
                    </div>
                  </div>
                </div>

                <div className="bento-card p-5 bg-brand-green/5 border-brand-green/10">
                  <p className="text-[10px] font-black text-brand-green uppercase tracking-widest mb-3 italic">
                    {station.statusInferredBy === 'traffic' ? 'Fila Estimada (IA)' : 'Fila na Estrada'}
                  </p>
                  <div className="flex flex-col items-center justify-center h-full gap-1 py-1">
                    <p className="text-2xl font-black text-brand-black italic">
                      {station.entryQueueLength ? `${station.entryQueueLength}+` : '0'}
                    </p>
                    <p className="text-[8px] font-black text-slate-400 uppercase">
                      {station.statusInferredBy === 'traffic' ? 'Simulação de Veículos' : 'Veículos em Espera'}
                    </p>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  <div className="bento-card p-5 bg-slate-50/50 border-slate-100 flex-1">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 italic">Fluxo Médio</p>
                    <p className="text-2xl font-black text-slate-900 italic uppercase">
                      {station.queueStatus === 'none' ? 'Livre' : 
                       station.queueStatus === 'short' ? 'Curta' : 
                       station.queueStatus === 'medium' ? 'Média' : 
                       station.queueStatus === 'long' ? 'Longa' : 'Extrema'}
                    </p>
                  </div>
                  <div className="bg-brand-green rounded-3xl p-4 text-white shadow-lg shadow-brand-green/10 flex flex-col gap-2">
                    <div>
                      <p className="text-[9px] font-black uppercase tracking-widest opacity-80 decoration-white/20">Última Verificação Humana</p>
                      <p className="text-sm font-black italic">
                        {station.lastHumanAt 
                          ? formatDistanceToNow((station.lastHumanAt as any).toDate ? (station.lastHumanAt as any).toDate() : station.lastHumanAt, { locale: pt, addSuffix: true })
                          : 'Nunca'}
                      </p>
                    </div>
                    <div>
                      <div className="flex justify-between items-center">
                        <p className="text-[9px] font-black uppercase tracking-widest opacity-80 decoration-white/20">Última Análise Satélite</p>
                        {station.satelliteUpdateCount && (
                          <span className="text-[8px] font-black bg-white/20 px-1.5 py-0.5 rounded-full">
                            {station.satelliteUpdateCount}x/h
                          </span>
                        )}
                      </div>
                      <p className="text-sm font-black italic">
                        {station.lastSatelliteAt 
                          ? formatDistanceToNow((station.lastSatelliteAt as any).toDate ? (station.lastSatelliteAt as any).toDate() : station.lastSatelliteAt, { locale: pt, addSuffix: true })
                          : 'Recentemente'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {station.statusInferredBy === 'traffic' && (
                <div className="p-4 bg-brand-yellow/10 border border-brand-yellow/30 rounded-3xl flex items-center gap-4">
                  <div className="w-10 h-10 rounded-2xl bg-brand-yellow flex items-center justify-center text-brand-black shadow-lg shadow-brand-yellow/20 shrink-0">
                    <Zap size={20} className="fill-brand-black animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs font-black text-brand-black uppercase italic leading-tight">Estado Previsto por IA</h4>
                    <p className="text-[10px] text-slate-600 font-medium leading-tight mt-1">
                      { (station.trafficCongestion || 0) >= 7
                        ? "Tráfego intenso detectado. Posto está certamente em operação de abastecimento."
                        : (station.trafficCongestion || 0) >= 3
                        ? "Actividade moderada detectada. Pode haver combustível com filas em formação."
                        : "Actividade baixa ou nula. Posto provavelmente sem stock ou encerrado temporariamente."
                      }
                    </p>
                    {station.aiConfidence && (
                      <div className="mt-2 flex items-center gap-2">
                        <div className="flex-1 h-1 bg-brand-yellow/30 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-brand-yellow transition-all duration-1000"
                            style={{ width: `${station.aiConfidence}%` }}
                          ></div>
                        </div>
                        <span className="text-[8px] font-black text-brand-black italic tracking-tighter">AI CONFIDENCE: {station.aiConfidence}%</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Traffic Intelligence Analysis */}
              <div className="bento-card p-6 bg-orange-50 border-orange-100">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-orange-600 flex items-center justify-center text-white shadow-lg shadow-orange-100">
                    <Activity size={20} className="animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-orange-950 uppercase italic leading-tight">Análise Automática de Tráfego</h4>
                    <p className="text-[9px] text-orange-700 font-bold uppercase tracking-tighter">Raio de 50m • Tempo Real</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[10px] font-black text-orange-900 uppercase italic">Estimativa de Fila</p>
                      <p className="text-xl font-black text-orange-700">
                        {station.trafficCongestion && station.trafficCongestion >= 8 ? '+30 Veículos' :
                         station.trafficCongestion && station.trafficCongestion >= 5 ? '15-30 Veículos' :
                         station.trafficCongestion && station.trafficCongestion >= 3 ? '5-15 Veículos' :
                         'Menos de 5 Veículos'}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-black text-orange-900 uppercase italic">Densidade</p>
                      <p className="text-sm font-black text-orange-700">
                        {station.trafficCongestion ? (station.trafficCongestion * 10) : 0}% de ocupação
                      </p>
                    </div>
                  </div>
                  
                  <div className="h-3 bg-orange-200/50 rounded-full overflow-hidden border border-orange-200">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(station.trafficCongestion || 0) * 10}%` }}
                      className={cn(
                        "h-full rounded-full transition-all",
                        (station.trafficCongestion || 0) >= 8 ? "bg-red-600" :
                        (station.trafficCongestion || 0) >= 5 ? "bg-orange-600" :
                        "bg-amber-500"
                      )}
                    />
                  </div>
                  
                  <p className="text-[10px] text-orange-800 font-medium leading-relaxed bg-white/40 p-3 rounded-lg border border-orange-100 italic">
                    {station.trafficCongestion && station.trafficCongestion >= 8 
                      ? "ALERTA CRÍTICO: Congestão extrema detectada na entrada do posto. É provável que a fila exceda 30 viaturas."
                      : station.trafficCongestion && station.trafficCongestion >= 4
                      ? "AVISO: Tráfego moderado detectado. Expectativa de espera superior a 15-20 minutos."
                      : station.lastReportedAt && (Date.now() - station.lastReportedAt.toMillis() > 600000) && (station.trafficCongestion || 0) >= 3
                      ? "ANÁLISE (10min): Tráfego persistente detectado mas sem reportes recentes. Possível interrupção ou pausa no abastecimento."
                      : "Tráfego normal. Acesso facilitado no perímetro do posto."}
                  </p>
                </div>
              </div>

              {/* Latest Opinions / User Feedback */}
              <div>
                <p className="text-[10px] font-black text-brand-black uppercase tracking-widest mb-4 flex items-center gap-2 italic">
                  <MessageSquare size={14} className="text-brand-green" /> Opiniões da Comunidade
                </p>
                <div className="space-y-4">
                  {reports.length === 0 ? (
                    <div className="text-center py-10 bg-slate-50/50 rounded-[32px] border border-dashed border-slate-200">
                      <p className="text-xs font-bold text-slate-400 italic px-6">Seja o primeiro a dar a sua opinião sobre a disponibilidade de combustível nesta bomba.</p>
                      <button 
                        onClick={() => setActiveTab('report')}
                        className="mt-4 text-[9px] font-black text-brand-green uppercase italic tracking-widest hover:underline"
                      >
                        Publicar Opinião
                      </button>
                    </div>
                  ) : (
                    reports.map(rep => (
                      <div key={rep.id} className="bg-slate-50 border border-slate-100 rounded-3xl p-5 relative overflow-hidden group">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-xl bg-white border border-slate-100 flex items-center justify-center text-[10px] font-black text-brand-green italic shadow-sm">
                              {rep.userName[0]}
                            </div>
                            <div>
                              <span className="text-xs font-black text-brand-black italic block">{rep.userName}</span>
                              <span className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">
                                {formatDistanceToNow(rep.createdAt?.toDate() || new Date(), { locale: pt, addSuffix: true })}
                              </span>
                            </div>
                          </div>
                          <div className="flex gap-1.5">
                            {rep.hasGasoline && <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" title="Gasolina"></div>}
                            {rep.hasDiesel && <div className="w-1.5 h-1.5 rounded-full bg-blue-500" title="Diesel"></div>}
                          </div>
                        </div>
                        
                        {rep.comment ? (
                          <div className="relative">
                            <span className="absolute -top-2 -left-1 text-brand-green/20 text-3xl font-serif">“</span>
                            <p className="text-[11px] text-slate-600 font-medium leading-relaxed italic relative z-10 pl-2">
                              {rep.comment}
                            </p>
                          </div>
                        ) : (
                          <p className="text-[10px] text-slate-400 font-bold uppercase italic">Reportou disponibilidade sem comentário</p>
                        )}
                        
                        <div className="mt-4 pt-3 border-t border-slate-100/50 flex flex-wrap gap-2">
                          <Badge variant={rep.queueLevel === 'none' || rep.queueLevel === 'short' ? 'success' : rep.queueLevel === 'medium' ? 'warning' : 'danger'} className="scale-[0.8] origin-left py-0 h-4">
                            Fila {rep.queueLevel}
                          </Badge>
                          <span className="text-[8px] font-black text-slate-400 uppercase italic">
                            • {rep.entryQueueLength || 0} Viaturas na entrada
                          </span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
              
              {station.currentStatus === 'unavailable' ? (
                <div className="bg-slate-100 p-4 rounded-2xl text-center">
                  <p className="text-[10px] font-black text-slate-500 uppercase italic">Operações Suspensas</p>
                </div>
              ) : (
                <Button onClick={() => setActiveTab('report')} className="w-full" size="lg">
                  FAZER NOVO REPORTE
                </Button>
              )}
            </motion.div>
          ) : station.currentStatus === 'unavailable' ? (
            <motion.div
              key="closed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-slate-50 border border-slate-100 rounded-[32px] p-10 text-center"
            >
              <div className="w-16 h-16 bg-slate-200 text-slate-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <X size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2 uppercase italic">Posto Encerrado</h3>
              <p className="text-sm text-slate-500 mb-8 font-medium">Não é possível fazer reportes enquanto a bomba estiver marcada como indisponível.</p>
              <Button onClick={() => setActiveTab('info')} className="w-full" variant="outline">Ver Detalhes</Button>
            </motion.div>
          ) : (
            <motion.div
              key="report"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="space-y-6"
            >
              {isVerifying ? (
                <div className="space-y-6">
                  <div className="bg-slate-50 border border-slate-100 rounded-[32px] p-6">
                    <p className="text-[10px] font-black text-brand-green uppercase tracking-widest mb-4 flex items-center gap-2 italic">
                      <Fuel size={14} /> Verificação de Bomba
                    </p>
                    <p className="text-xs text-slate-500 font-medium mb-6">
                      Confirme se os dados abaixo correspondem à realidade que você está vendo agora no posto.
                    </p>

                    <div className="space-y-3 mb-8">
                       <div className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100">
                         <span className="text-xs font-black text-slate-700 uppercase italic">Gasolina</span>
                         {station.hasGasoline ? <Badge variant="success">Disponível</Badge> : <Badge variant="outline">Indisponível</Badge>}
                       </div>
                       <div className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100">
                         <span className="text-xs font-black text-slate-700 uppercase italic">Diesel</span>
                         {station.hasDiesel ? <Badge variant="success">Disponível</Badge> : <Badge variant="outline">Indisponível</Badge>}
                       </div>
                       <div className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100">
                         <span className="text-xs font-black text-slate-700 uppercase italic">GNV</span>
                         {station.hasGNV ? <Badge variant="success">Disponível</Badge> : <Badge variant="outline">Indisponível</Badge>}
                       </div>
                       <div className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-100">
                         <span className="text-xs font-black text-slate-700 uppercase italic">Fila de Espera</span>
                         <span className="text-xs font-black text-brand-green italic uppercase">
                            {station.queueStatus === 'none' ? 'Livre' : 
                             station.queueStatus === 'short' ? 'Curta' : 
                             station.queueStatus === 'medium' ? 'Média' : 
                             station.queueStatus === 'long' ? 'Longa' : 'Extrema'}
                         </span>
                       </div>
                    </div>

                    <div className="flex flex-col gap-3">
                      <Button 
                        onClick={handleSubmit} 
                        className="w-full py-4 text-base flex gap-2 shadow-lg shadow-brand-green/20"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? 'PROCESSANDO...' : (
                          <>
                            <Check size={20} /> CONFIRMAR STATUS ATUAL
                          </>
                        )}
                      </Button>
                      <Button 
                        variant="outline" 
                        onClick={() => setIsVerifying(false)} 
                        className="w-full py-4 text-xs flex gap-2 border-slate-200 text-slate-600"
                        disabled={isSubmitting}
                      >
                        <Edit3 size={16} /> CORRIGIR OU ADICIONAR DETALHES
                      </Button>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl">
                    <p className="text-[9px] text-blue-700 font-bold uppercase tracking-wider leading-relaxed">
                      💡 A confirmção rápida ajuda a manter os dados frescos sem precisar preencher todo o formulário.
                    </p>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Fuel Status */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <Fuel size={14} className="text-brand-green" /> Disponibilidade de Combustível
                      </p>
                      {!hasGasoline && !hasDiesel && !hasGNV && (
                         <span className="text-[9px] font-black text-brand-yellow uppercase italic animate-pulse">Confirmar tipos de combustível</span>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-3">
                      {[
                        { id: 'gas', label: 'Gasolina', val: hasGasoline, set: setHasGasoline },
                        { id: 'die', label: 'Diesel', val: hasDiesel, set: setHasDiesel },
                        { id: 'gnv', label: 'GNV', val: hasGNV, set: setHasGNV },
                      ].map(item => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => item.set(!item.val)}
                          className={cn(
                            "py-4 px-2 rounded-2xl border-2 transition-all font-black text-xs uppercase italic tracking-tighter",
                            item.val 
                              ? "border-emerald-500 bg-emerald-50 text-emerald-900" 
                              : "border-slate-50 bg-slate-50 text-slate-300 opacity-60"
                          )}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Queue Status */}
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                       <Clock size={14} className="text-brand-green" /> Fluxo de Atendimento
                    </p>
                    <div className="grid grid-cols-5 gap-2">
                      {queueOptions.map(opt => (
                        <button
                          key={opt.value}
                          type="button"
                          onClick={() => setQueueLevel(opt.value)}
                          className={cn(
                            "flex flex-col items-center gap-2 transition-all p-1.5 rounded-xl border-2",
                            queueLevel === opt.value 
                              ? "border-brand-green bg-brand-green/5 scale-105" 
                              : "border-transparent opacity-40 grayscale"
                          )}
                        >
                          <div className={cn("w-full h-8 rounded-lg shadow-sm", opt.color)} />
                          <span className="text-[8px] font-black uppercase tracking-tighter truncate w-full text-center italic">{opt.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Entry Queue Length */}
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                       <Activity size={14} className="text-brand-yellow" /> Fila de Entrada (Aproximada)
                    </p>
                    <div className="space-y-4">
                      <div className="flex justify-between text-xs font-black text-slate-900 italic uppercase">
                        <span>Livre</span>
                        <span className="text-brand-green">{entryQueueValue >= 50 ? '50+ Carros' : `${entryQueueValue} Carros`}</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="50" 
                        step="5"
                        value={entryQueueValue}
                        onChange={(e) => setEntryQueueValue(parseInt(e.target.value))}
                        className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-brand-green"
                      />
                      <div className="grid grid-cols-5 gap-2">
                        {[0, 10, 20, 30, 50].map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => setEntryQueueValue(val)}
                            className={cn(
                              "py-2 rounded-lg text-[10px] font-black transition-all",
                              entryQueueValue === val ? "bg-brand-green text-white shadow-md" : "bg-slate-50 text-slate-400 hover:bg-slate-100"
                            )}
                          >
                            {val === 50 ? '50+' : val}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Comment */}
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                       <MessageSquare size={14} className="text-brand-green" /> Opinião / Detalhes Adicionais
                    </p>
                    <textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Ex: 'Acabou de chegar camião', 'Só aceitam numerário', 'Fila enorme mas flui'..."
                      className="w-full rounded-2xl border-2 border-slate-50 bg-slate-50 p-4 text-sm font-medium focus:border-brand-green outline-none transition-colors min-h-[100px] text-slate-700"
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button 
                      type="button" 
                      variant="outline"
                      className="flex-1 py-5"
                      onClick={() => setActiveTab('info')}
                      disabled={isSubmitting}
                    >
                      CANCELAR
                    </Button>
                    <Button 
                      type="submit" 
                      className="flex-[2] py-5 text-base flex gap-3 shadow-lg shadow-brand-green/20"
                      disabled={isSubmitting}
                      size="lg"
                    >
                      {isSubmitting ? 'PROCESSANDO...' : (
                        <>
                          <Send size={20} /> PUBLICAR REPORTE
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              )}
            </motion.div>
            )}
          </AnimatePresence>
        </div>
    </motion.div>
  );
}
