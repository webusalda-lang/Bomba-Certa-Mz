import React from 'react';
import { Station, QueueLevel } from '../types';
import { Badge, Button, cn } from './Common';
import { Fuel, Clock, MapPin, ChevronRight, Activity, Zap, PlusCircle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { pt } from 'date-fns/locale';

interface StationListProps {
  stations: Station[];
  onSelectStation: (station: Station) => void;
  userLocation: { lat: number; lng: number } | null;
}

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371; // km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

export default function StationList({ 
  stations, 
  onSelectStation, 
  userLocation 
}: StationListProps) {
  // Sorting based on proximity if location is available
  const sortedStations = [...stations].sort((a, b) => {
    if (userLocation) {
      const distA = calculateDistance(userLocation.lat, userLocation.lng, a.location.lat, a.location.lng);
      const distB = calculateDistance(userLocation.lat, userLocation.lng, b.location.lat, b.location.lng);
      return distA - distB;
    }
    return 0; // Default no sort here, sections will sort by time
  });

  // Group stations by status
  const available = stations.filter(s => s.currentStatus === 'available');
  const uncertain = stations.filter(s => s.currentStatus === 'unknown');
  const unavailable = stations.filter(s => s.currentStatus === 'unavailable');

  const renderSection = (title: string, stationGroup: Station[], colorClass: string) => {
    if (stationGroup.length === 0) return null;
    
    return (
      <div className="space-y-4">
        <h2 className={cn("text-[10px] font-black uppercase tracking-[0.2em] italic ml-2 flex items-center gap-2", colorClass)}>
          <Fuel size={12} /> {title} ({stationGroup.length})
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-4">
          {stationGroup.sort((a, b) => {
            // Sort by distance if user location is available
            if (userLocation) {
              const distA = calculateDistance(userLocation.lat, userLocation.lng, a.location.lat, a.location.lng);
              const distB = calculateDistance(userLocation.lat, userLocation.lng, b.location.lat, b.location.lng);
              if (Math.abs(distA - distB) > 0.1) { // Only sort by distance if difference is notable
                return distA - distB;
              }
            }
            
            // Otherwise sort by time
            const timeA = (a.updatedAt as any)?.toDate?.()?.getTime() || 
                          (a.updatedAt instanceof Date ? a.updatedAt.getTime() : 0);
            const timeB = (b.updatedAt as any)?.toDate?.()?.getTime() || 
                          (b.updatedAt instanceof Date ? b.updatedAt.getTime() : 0);
            return timeB - timeA;
          }).map(station => {
            const isClosed = station.currentStatus === 'unavailable';
            const lastUpdated = station.updatedAt 
              ? formatDistanceToNow((station.updatedAt as any).toDate ? (station.updatedAt as any).toDate() : station.updatedAt, { locale: pt, addSuffix: true })
              : 'Sem dados';

            const distance = userLocation ? calculateDistance(
              userLocation.lat, 
              userLocation.lng, 
              station.location.lat, 
              station.location.lng
            ).toFixed(1) : null;
            
            return (
              <div 
                key={station.id}
                onClick={() => onSelectStation(station)}
                className={cn(
                  "bento-card p-4 md:p-5 active:scale-[0.98] transition-all cursor-pointer relative overflow-hidden group",
                  isClosed && "opacity-75 grayscale-[0.3] border-slate-200"
                )}
              >
                <div className="flex flex-col gap-4 mb-4">
                  <div className="flex gap-3 md:gap-4 items-start">
                    <div className={cn(
                      "h-12 w-12 md:h-14 md:w-14 rounded-xl md:rounded-2xl flex items-center justify-center text-white font-black italic shadow-lg uppercase text-sm md:text-base shrink-0",
                      isClosed ? "bg-slate-400 shadow-slate-100" : (station.currentStatus === 'available' ? "bg-brand-green" : "bg-brand-yellow")
                    )}>
                      {station.brand[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap mb-1">
                        <h3 className="font-black text-brand-black text-base md:text-xl uppercase italic leading-tight truncate">{station.name}</h3>
                        {station.id.startsWith('temp-') && (
                          <Badge variant="info" className="scale-75 origin-left">Google</Badge>
                        )}
                      </div>
                      <p className="text-[9px] md:text-[10px] text-slate-400 font-bold uppercase tracking-[0.1em] md:tracking-[0.2em]">
                        {station.address || station.brand}
                      </p>
                      {distance && (
                        <div className="flex items-center gap-1 mt-1">
                          <MapPin size={8} className="text-brand-green" />
                          <span className="text-[8px] font-black text-brand-green uppercase italic">{distance} km de distância</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {station.currentStatus === 'available' ? (
                      <Badge variant="success" className="font-black italic uppercase text-[10px] md:text-xs py-1.5 px-3 flex items-center gap-2 w-full sm:w-auto justify-center sm:justify-start">
                        <Fuel size={14} /> A Abastecer
                      </Badge>
                    ) : station.currentStatus === 'unavailable' ? (
                      <Badge variant="danger" className="font-black italic uppercase text-[10px] md:text-xs py-1.5 px-3 flex items-center gap-2 w-full sm:w-auto justify-center sm:justify-start">
                        <Fuel size={14} className="rotate-180" /> Sem Stock
                      </Badge>
                    ) : (
                      <Badge variant="warning" className="font-black italic uppercase text-[10px] md:text-xs py-1.5 px-3 flex items-center gap-2 w-full sm:w-auto justify-center sm:justify-start">
                        <Fuel size={14} /> Stock Incerto
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 mb-4">
                  {[
                    { label: 'Gasolina', val: station.hasGasoline },
                    { label: 'Diesel', val: station.hasDiesel },
                    { label: 'GNV', val: station.hasGNV }
                  ].map(item => (
                    <div key={item.label} className={cn(
                      "flex flex-col p-1.5 md:p-2 rounded-xl border transition-all",
                      item.val 
                        ? "bg-emerald-50 border-emerald-100/50" 
                        : "bg-slate-50 border-slate-100 opacity-40 grayscale"
                    )}>
                      <p className={cn("text-[6px] md:text-[7px] font-black uppercase tracking-tighter mb-0.5", item.val ? "text-emerald-600" : "text-slate-400")}>
                        {item.label}
                      </p>
                      <p className={cn("text-[9px] md:text-[10px] font-black italic", item.val ? "text-emerald-900" : "text-slate-400")}>
                        {item.val ? 'SIM' : 'NÃO'}
                      </p>
                    </div>
                  ))}
                </div>

                {station.currentStatus === 'available' && !station.hasGasoline && !station.hasDiesel && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectStation(station);
                    }}
                    className="w-full mb-4 py-2 bg-brand-yellow/10 border border-brand-yellow/20 rounded-xl text-[8px] md:text-[9px] font-black text-brand-black uppercase italic tracking-widest hover:bg-brand-yellow/20 transition-all flex items-center justify-center gap-2"
                  >
                    <PlusCircle size={10} /> Confirmar tipos de combustível
                  </button>
                )}

                {station.lastComment && (
                  <div className="mb-4 bg-brand-green/5 p-2.5 md:p-3 rounded-2xl border border-brand-green/10 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-brand-green/20"></div>
                    <p className="text-[8px] md:text-[10px] text-brand-green font-black uppercase italic tracking-widest mb-1 opacity-60">Última Opinião</p>
                    <p className="text-[10px] md:text-[11px] text-slate-600 font-medium italic line-clamp-2 leading-relaxed">
                      "{station.lastComment}"
                    </p>
                    <p className="text-[7px] md:text-[8px] text-slate-400 font-bold uppercase mt-1 tracking-tighter">— {station.lastCommenter}</p>
                  </div>
                )}

                <div className="pt-3 border-t border-slate-50 mt-auto space-y-2">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center justify-between">
                      <div className="flex flex-col gap-0.5">
                        <div className="flex items-center gap-2 text-[8px] md:text-[9px] text-slate-400 font-bold uppercase tracking-widest italic">
                          <Zap size={10} className="text-brand-yellow" />
                          <span>Análise Satélite: {station.lastSatelliteAt 
                            ? formatDistanceToNow((station.lastSatelliteAt as any).toDate ? (station.lastSatelliteAt as any).toDate() : station.lastSatelliteAt, { locale: pt, addSuffix: true })
                            : 'Actualizando...'}
                          </span>
                        </div>
                        {station.aiConfidence && (
                          <div className="flex items-center gap-1.5 ml-4">
                            <div className="w-10 h-1 bg-slate-100 rounded-full overflow-hidden">
                              <div 
                                className={cn(
                                  "h-full transition-all duration-1000",
                                  station.aiConfidence > 80 ? "bg-brand-green" : station.aiConfidence > 50 ? "bg-brand-yellow" : "bg-red-400"
                                )} 
                                style={{ width: `${station.aiConfidence}%` }}
                              ></div>
                            </div>
                            <span className={cn(
                              "text-[7px] font-black italic",
                              station.aiConfidence > 80 ? "text-brand-green" : station.aiConfidence > 50 ? "text-brand-yellow" : "text-red-400"
                            )}>
                              {station.aiConfidence}% Confiança
                            </span>
                          </div>
                        )}
                      </div>
                      {station.satelliteUpdateCount && (
                        <span className="text-[7px] font-black text-brand-yellow bg-brand-yellow/5 px-1.5 py-0.5 rounded-full border border-brand-yellow/10">
                          {station.satelliteUpdateCount}x / h
                        </span>
                      )}
                    </div>
                    {station.lastHumanAt && (
                      <div className="flex items-center gap-2 text-[8px] md:text-[9px] text-brand-green font-bold uppercase tracking-widest italic">
                        <Activity size={10} />
                        <span>Verificação Humana: {formatDistanceToNow((station.lastHumanAt as any).toDate ? (station.lastHumanAt as any).toDate() : station.lastHumanAt, { locale: pt, addSuffix: true })}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2 text-[8px] md:text-[9px] text-slate-300 font-bold uppercase tracking-widest italic">
                      <Clock size={10} />
                      <span>Geral: {lastUpdated}</span>
                    </div>
                    <div className="w-6 h-6 md:w-7 md:h-7 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 group-hover:text-brand-green group-hover:bg-brand-green/5 transition-colors">
                      <ChevronRight size={14} />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-8 md:space-y-10 h-full pt-28">
      {stations.length === 0 ? (
        <div className="text-center py-20 text-slate-400">
          <MapPin size={48} className="mx-auto mb-4 opacity-20" />
          <p className="font-bold text-xs md:text-sm uppercase italic">Nenhuma bomba encontrada nas proximidades.</p>
        </div>
      ) : (
        <>
          {renderSection("A ABASTECER (Fluxo Detectado)", available, "text-brand-green")}
          {renderSection("STOCK INCERTO (Actividade Moderada)", uncertain, "text-brand-yellow")}
          {renderSection("SEM STOCK (Actividade Nula)", unavailable, "text-red-500")}
        </>
      )}
    </div>
  );
}
