import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function Badge({ children, className, variant = 'default' }: { 
  children: React.ReactNode, 
  className?: string,
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'outline'
}) {
  const variants = {
    default: 'bg-slate-100 text-slate-800',
    success: 'bg-brand-green/5 text-brand-green border border-brand-green/20',
    warning: 'bg-brand-yellow/10 text-brand-black border border-brand-yellow/20',
    danger: 'bg-red-50 text-red-700 border border-red-100',
    info: 'bg-brand-yellow text-brand-black border border-brand-yellow/20 font-black italic shadow-sm',
    outline: 'border border-slate-200 text-slate-600'
  };

  return (
    <span className={cn(
      "inline-flex items-center px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider",
      variants[variant],
      className
    )}>
      {children}
    </span>
  );
}

export function Button({ 
  children, 
  className, 
  variant = 'primary', 
  size = 'md',
  ...props 
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { 
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger',
  size?: 'sm' | 'md' | 'lg' | 'icon'
}) {
  const variants = {
    primary: 'bg-brand-green text-white hover:bg-brand-green/90 shadow-md shadow-brand-green/20',
    secondary: 'bg-brand-black text-white hover:bg-brand-black/90 shadow-sm',
    outline: 'border border-brand-green/20 bg-white text-slate-700 hover:bg-slate-50',
    ghost: 'text-slate-600 hover:bg-slate-100',
    danger: 'bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-200'
  };

  const sizes = {
    sm: 'px-4 py-2 rounded-xl text-xs font-bold',
    md: 'px-5 py-2.5 rounded-2xl text-sm font-bold',
    lg: 'px-8 py-4 rounded-3xl text-lg font-black italic uppercase tracking-tight',
    icon: 'p-2 rounded-xl'
  };

  return (
    <button 
      className={cn(
        "inline-flex items-center justify-center rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-brand-green focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed",
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
